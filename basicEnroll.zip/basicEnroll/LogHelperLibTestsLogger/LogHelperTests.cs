﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LogHelperLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogHelperLib.Tests
{
    [TestClass()]
    public class LogHelperTests
    {
        [TestMethod()]
        public void LogTest()
        {
            Assert.Fail();
        }
    }
}